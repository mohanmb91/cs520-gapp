package springmvc.model.dao;
import java.util.List;

import springmvc.model.AdditionalDepartmentFeilds;
import springmvc.model.Department;
import springmvc.model.Program;
import springmvc.model.UserRole;
public interface DepartmentsDao {
	
	List<Department> getDepartments();
	
	Department getDepartmentById(Integer id);
	
	Department saveDepartment(Department department);

	AdditionalDepartmentFeilds savedditionalDepartmentFeilds(AdditionalDepartmentFeilds additionalDepartmentFeilds);

	AdditionalDepartmentFeilds getAdditionalDepartmentFeilds(Integer id);

	void removeDepartment(Integer id);
	
	void removeAdditionalFeild(Integer id);
	
	

	}
